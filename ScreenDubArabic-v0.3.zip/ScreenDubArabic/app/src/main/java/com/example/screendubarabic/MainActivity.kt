package com.example.screendubarabic

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Rect
import android.graphics.YuvImage
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.translate.TranslateLanguage
import com.google.mlkit.translate.Translation
import com.google.mlkit.translate.Translator
import com.google.mlkit.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private lateinit var detected: TextView
    private lateinit var tts: TextToSpeech
    private lateinit var latinRecognizer: TextRecognizer
    private lateinit var translator: Translator
    private var translatorReady = false
    private var arabicOcr: TessBaseAPI? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val running = AtomicBoolean(false)
    @Volatile private var busy = false
    @Volatile private var bottomPercent = 42
    private var lastText = ""
    private var lastSpoken = ""
    private var lastTime = 0L
    private var voiceSpeed = 1.0f

    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) startCamera() else status.text = "Camera permission denied"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        latinRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        translator = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.ARABIC).build()
        )
        translator.downloadModelIfNeeded().addOnSuccessListener {
            translatorReady = true; status.text = "English → Arabic model ready"
        }.addOnFailureListener { status.text = "Translation model download failed; check internet." }
        preview = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        status = TextView(this).apply { text = "Ready"; textSize = 15f; gravity = Gravity.CENTER }
        initArabicOCR()
        detected = TextView(this).apply {
            text = "Detected text appears here"; textSize = 16f; gravity = Gravity.CENTER
        }
        val start = Button(this).apply {
            text = "Start reading"
            setOnClickListener {
                running.set(!running.get())
                text = if (running.get()) "Stop reading" else "Start reading"
                if (running.get()) {
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA)
                        == PackageManager.PERMISSION_GRANTED) startCamera()
                    else permission.launch(Manifest.permission.CAMERA)
                } else { tts.stop(); status.text = "Paused" }
            }
        }
        val roiLabel = TextView(this).apply { text = "Subtitle zone: bottom ${bottomPercent}%"; gravity = Gravity.CENTER }
        val roiSlider = SeekBar(this).apply {
            max = 70; progress = bottomPercent - 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    bottomPercent = p + 20; roiLabel.text = "Subtitle zone: bottom $bottomPercent%"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(roiLabel); addView(roiSlider)
            addView(detected, LinearLayout.LayoutParams(-1, -2))
            addView(status, LinearLayout.LayoutParams(-1, -2))
            addView(start, LinearLayout.LayoutParams(-1, -2))
        }
        setContentView(layout)
    }

    private fun initArabicOCR() {
        try {
            val root = File(filesDir, "tessdata")
            root.mkdirs()
            val trained = File(root, "ara.traineddata")
            if (!trained.exists()) {
                try {
                    assets.open("tessdata/ara.traineddata").use { input ->
                        FileOutputStream(trained).use { output -> input.copyTo(output) }
                    }
                } catch (_: Exception) {
                    status.text = "Arabic OCR unavailable: add assets/tessdata/ara.traineddata"
                    return
                }
            }
            arabicOcr = TessBaseAPI().also { it.init(filesDir.absolutePath, "ara") }
        } catch (e: Exception) { status.text = "Arabic OCR init error: ${e.message}" }
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(executor) { proxy ->
                if (!running.get() || busy) { proxy.close(); return@setAnalyzer }
                val media = proxy.image
                if (media == null) { proxy.close(); return@setAnalyzer }
                busy = true
                val input = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                latinRecognizer.process(input).addOnSuccessListener { result ->
                    val cutoff = (proxy.height * (100 - bottomPercent) / 100)
                    val latinText = result.textBlocks.filter { block ->
                        block.boundingBox?.let { it.bottom > cutoff } ?: true
                    }.joinToString(" ") { it.text }.trim()
                    val bitmap = yuvToBitmap(proxy)
                    val arabicText = bitmap?.let { runArabicOCR(it, cutoff) }.orEmpty()
                    val combined = chooseText(latinText, arabicText)
                    if (combined.isNotBlank()) processText(combined)
                }.addOnFailureListener {
                    runOnUiThread { status.text = "OCR error: ${it.localizedMessage ?: ""}" }
                }.addOnCompleteListener {
                    busy = false; proxy.close()
                }
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUseCase, analysis)
            } catch (e: Exception) { status.text = "Camera error: ${e.message}" }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun chooseText(latin: String, arabic: String): String {
        val a = arabic.trim(); val l = latin.trim()
        if (a.isNotBlank() && a.any { it in '\\u0600'..'\\u06FF' }) return a
        return l
    }

    private fun runArabicOCR(bitmap: Bitmap, cutoff: Int): String {
        val api = arabicOcr ?: return ""
        return try {
            val top = (bitmap.height * (100 - bottomPercent) / 100).coerceIn(0, bitmap.height - 1)
            val cropped = Bitmap.createBitmap(bitmap, 0, top, bitmap.width, bitmap.height - top)
            api.setImage(cropped)
            val text = api.getUTF8Text()?.trim().orEmpty()
            cropped.recycle()
            text
        } catch (_: Exception) { "" }
    }

    private fun yuvToBitmap(image: androidx.camera.core.ImageProxy): Bitmap? {
        try {
            val y = image.planes[0].buffer
            val u = image.planes[1].buffer
            val v = image.planes[2].buffer
            val ySize = y.remaining(); val uSize = u.remaining(); val vSize = v.remaining()
            val nv21 = ByteArray(ySize + uSize + vSize)
            y.get(nv21, 0, ySize)
            // CameraX commonly provides V and U planes with pixel stride 2; interleave VU for NV21.
            val width = image.width; val height = image.height
            val chromaWidth = width / 2; val chromaHeight = height / 2
            var offset = ySize
            val uBuf = image.planes[1]; val vBuf = image.planes[2]
            val ub = uBuf.buffer; val vb = vBuf.buffer
            for (row in 0 until chromaHeight) for (col in 0 until chromaWidth) {
                val uIndex = row * uBuf.rowStride + col * uBuf.pixelStride
                val vIndex = row * vBuf.rowStride + col * vBuf.pixelStride
                if (vIndex < vb.limit() && uIndex < ub.limit()) {
                    nv21[offset++] = vb.get(vIndex)
                    nv21[offset++] = ub.get(uIndex)
                }
            }
            val out = ByteArrayOutputStream()
            YuvImage(nv21, android.graphics.ImageFormat.NV21, width, height, null)
                .compressToJpeg(Rect(0, 0, width, height), 65, out)
            val bmp = android.graphics.BitmapFactory.decodeByteArray(out.toByteArray(), 0, out.size())
            return bmp
        } catch (_: Exception) { return null }
    }

    private fun processText(raw: String) {
        val cleaned = raw.replace("\\s+".toRegex(), " ").trim()
        if (cleaned.length < 3 || cleaned == lastText) return
        lastText = cleaned
        val now = System.currentTimeMillis()
        if (cleaned == lastSpoken && now - lastTime < 7000) return
        lastSpoken = cleaned; lastTime = now
        val isArabic = cleaned.any { it in '\\u0600'..'\\u06FF' }
        if (isArabic) speak(cleaned)
        else if (translatorReady) {
            translator.translate(cleaned).addOnSuccessListener { speak(it) }
                .addOnFailureListener { runOnUiThread { status.text = "Translation failed" } }
        } else status.text = "Translation model downloading; please wait"
        runOnUiThread { detected.text = cleaned; status.text = if (isArabic) "Arabic text" else "English detected → translating" }
    }

    private fun speak(text: String) {
        runOnUiThread {
            if (tts.setLanguage(Locale("ar")) >= TextToSpeech.LANG_AVAILABLE) {
                tts.setSpeechRate(voiceSpeed)
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "screen-dub-${System.currentTimeMillis()}")
            } else status.text = "Arabic voice not installed. Add Arabic voice in Android TTS settings."
        }
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) tts.setLanguage(Locale("ar"))
    }

    override fun onDestroy() {
        running.set(false); latinRecognizer.close(); translator.close()
        arabicOcr?.end(); tts.stop(); tts.shutdown(); executor.shutdown()
        super.onDestroy()
    }
}
