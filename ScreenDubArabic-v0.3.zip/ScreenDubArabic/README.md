# ScreenDub Arabic — prototype 0.3

Android camera-based subtitle reader prototype.

- CameraX live camera preview and analysis
- ML Kit Latin OCR for English text
- On-device English-to-Arabic translation (model downloads on first use)
- Arabic text-to-speech
- Optional Tesseract Arabic OCR (requires `ara.traineddata`)
- Adjustable lower subtitle region
- Duplicate-text suppression

## Build on Android
1. Open this project in Android Studio.
2. Allow Gradle sync and dependencies to download.
3. Optional Arabic OCR: place `ara.traineddata` in `app/src/main/assets/tessdata/`.
4. Build > Build APK(s).
5. Install the APK and grant camera permission.

This archive is source code, not a prebuilt APK. Build and test on a device before relying on it.
