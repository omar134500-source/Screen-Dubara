# ScreenDub Arabic — 0.7

يقرأ **النص العربي فقط** من الكاميرا وينطقه. بدون إنجليزية وبدون ترجمة.

- Higher camera resolution + image contrast + two reads (normal/inverted) for white subtitles
- Only Arabic letters are kept; noise, digits and Latin text are ignored
- Accurate Arabic model (tessdata_best) downloaded once on first launch, then works offline
- Build: GitHub Actions (see .github/workflows) or Android Studio (JDK 17)
