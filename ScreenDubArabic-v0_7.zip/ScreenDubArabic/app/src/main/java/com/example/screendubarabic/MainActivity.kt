package com.example.screendubarabic

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Reads Arabic text from the camera and speaks it. Arabic only: no English, no translation. */
class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var preview: PreviewView
    private lateinit var guide: View
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var startButton: Button
    private lateinit var tts: TextToSpeech

    private var ttsReady = false
    @Volatile private var ocr: TessBaseAPI? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val running = AtomicBoolean(false)
    @Volatile private var bottomPercent = 35
    @Volatile private var voiceSpeed = 1.0f
    private var lastWords: Set<String> = emptySet()
    private var lastAnalysis = 0L
    private var cameraStarted = false

    private val permission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) beginReading() else setStatus("لم يتم السماح باستخدام الكاميرا")
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        tts = TextToSpeech(this, this)
        setStatus("جارٍ تجهيز القراءة العربية…")
        executor.execute { initArabicOcr() }
    }

    // ---------- UI ----------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.parseColor("#111111"))
        }
        preview = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        guide = View(this).apply {
            background = GradientDrawable().apply {
                setStroke(dp(3), Color.parseColor("#FFC107"))
                setColor(Color.parseColor("#22FFC107"))
                cornerRadius = dp(8).toFloat()
            }
        }
        val frame = FrameLayout(this).apply {
            addView(preview, FrameLayout.LayoutParams(-1, -1))
            addView(guide)
        }
        frame.addOnLayoutChangeListener { _, _, t, _, b, _, _, _, _ -> updateGuide(b - t) }
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        result = TextView(this).apply {
            text = "سيظهر النص العربي هنا"
            textSize = 26f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE); gravity = Gravity.CENTER
            minLines = 2; maxLines = 4; setPadding(dp(12), dp(8), dp(12), dp(4))
        }
        status = TextView(this).apply {
            textSize = 13f; setTextColor(Color.parseColor("#FFC107")); gravity = Gravity.CENTER
        }
        root.addView(result, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))

        val settings = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            setPadding(dp(16), dp(4), dp(16), dp(4))
        }
        val zoneLabel = label("منطقة القراءة: أسفل $bottomPercent%")
        val zoneSlider = SeekBar(this).apply {
            max = 60; progress = bottomPercent - 20
            setOnSeekBarChangeListener(simpleSeek { p ->
                bottomPercent = p + 20
                zoneLabel.text = "منطقة القراءة: أسفل $bottomPercent%"
                updateGuide(preview.height)
            })
        }
        val speedLabel = label("سرعة الصوت: 1.0×")
        val speedSlider = SeekBar(this).apply {
            max = 15; progress = 5
            setOnSeekBarChangeListener(simpleSeek { p ->
                voiceSpeed = 0.5f + p / 10f
                speedLabel.text = "سرعة الصوت: ${"%.1f".format(Locale.US, voiceSpeed)}×"
            })
        }
        listOf(zoneLabel, zoneSlider, speedLabel, speedSlider).forEach { settings.addView(it) }
        root.addView(settings, LinearLayout.LayoutParams(-1, -2))

        val settingsButton = Button(this).apply {
            text = "الإعدادات"; isAllCaps = false
            setOnClickListener {
                settings.visibility = if (settings.visibility == View.GONE) View.VISIBLE else View.GONE
            }
        }
        startButton = Button(this).apply {
            text = "ابدأ القراءة"; textSize = 20f; isAllCaps = false
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2E7D32")); cornerRadius = dp(14).toFloat()
            }
            minHeight = dp(64)
            setOnClickListener { toggle() }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), dp(6), dp(12), dp(12))
            addView(startButton, LinearLayout.LayoutParams(0, -2, 2.2f))
            addView(settingsButton, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        }
        root.addView(row, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun label(t: String) = TextView(this).apply { text = t; setTextColor(Color.WHITE) }

    private fun simpleSeek(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) = onChange(p)
        override fun onStartTrackingTouch(sb: SeekBar?) {}
        override fun onStopTrackingTouch(sb: SeekBar?) {}
    }

    private fun updateGuide(parentHeight: Int) {
        if (parentHeight <= 0) return
        val h = parentHeight * bottomPercent / 100
        guide.layoutParams = FrameLayout.LayoutParams(-1, h, Gravity.BOTTOM).apply {
            setMargins(dp(6), 0, dp(6), dp(6))
        }
    }

    private fun setStatus(t: String) = runOnUiThread { status.text = t }

    // ---------- Start / stop ----------
    private fun toggle() {
        if (running.get()) {
            running.set(false); tts.stop()
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            startButton.text = "ابدأ القراءة"; setStatus("متوقف مؤقتًا")
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) beginReading()
        else permission.launch(Manifest.permission.CAMERA)
    }

    private fun beginReading() {
        if (ocr == null) { setStatus("القراءة العربية ليست جاهزة بعد، انتظر لحظات وحاول مجددًا"); return }
        running.set(true); lastWords = emptySet()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        startButton.text = "إيقاف"
        setStatus("وجّه الكاميرا إلى الترجمة العربية داخل الإطار الأصفر")
        if (!cameraStarted) startCamera()
    }

    // ---------- Camera ----------
    private fun startCamera() {
        cameraStarted = true
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                // Higher resolution than the default (640x480): Arabic letters need the detail.
                .setResolutionSelector(
                    ResolutionSelector.Builder().setResolutionStrategy(
                        ResolutionStrategy(Size(1280, 720), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                    ).build()
                )
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(executor) { proxy -> analyze(proxy) }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUseCase, analysis)
            } catch (e: Exception) { setStatus("خطأ في الكاميرا: ${e.message}") }
        }, ContextCompat.getMainExecutor(this))
    }

    /** Runs on the background executor, so OCR never blocks the UI. */
    private fun analyze(proxy: ImageProxy) {
        try {
            val now = System.currentTimeMillis()
            if (!running.get() || now - lastAnalysis < 900) return
            lastAnalysis = now
            val api = ocr ?: return

            val rotated = rotate(proxy.toBitmap(), proxy.imageInfo.rotationDegrees)
            val top = (rotated.height * (100 - bottomPercent) / 100).coerceIn(0, rotated.height - 1)
            val crop = Bitmap.createBitmap(rotated, 0, top, rotated.width, rotated.height - top)

            // Try dark-on-light and light-on-dark (white subtitles); keep the more confident read.
            var bestText = ""; var bestConf = 0
            for (invert in listOf(false, true)) {
                val img = prepare(crop, invert)
                api.setImage(img)
                val raw = api.utF8Text.orEmpty()
                val conf = api.meanConfidence()
                img.recycle()
                val clean = arabicOnly(raw)
                if (isReadable(clean) && conf > bestConf) { bestText = clean; bestConf = conf }
            }
            if (bestConf >= 60 && bestText.isNotBlank()) handleText(bestText)
        } catch (e: Exception) {
            setStatus("خطأ: ${e.localizedMessage ?: ""}")
        } finally {
            proxy.close()
        }
    }

    private fun rotate(bmp: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return bmp
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height,
            Matrix().apply { postRotate(degrees.toFloat()) }, true)
    }

    /** Grayscale + strong contrast (optionally inverted) to make letters stand out. */
    private fun prepare(src: Bitmap, invert: Boolean): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val cm = ColorMatrix().apply { setSaturation(0f) }
        if (invert) cm.postConcat(ColorMatrix(floatArrayOf(
            -1f, 0f, 0f, 0f, 255f,
            0f, -1f, 0f, 0f, 255f,
            0f, 0f, -1f, 0f, 255f,
            0f, 0f, 0f, 1f, 0f)))
        val c = 1.8f; val t = 255f * (1f - c) / 2f
        cm.postConcat(ColorMatrix(floatArrayOf(
            c, 0f, 0f, 0f, t,
            0f, c, 0f, 0f, t,
            0f, 0f, c, 0f, t,
            0f, 0f, 0f, 1f, 0f)))
        Canvas(out).drawBitmap(src, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })
        return out
    }

    // ---------- Text filtering ----------
    private fun isArabic(c: Char) = c in '\u0600'..'\u06FF'

    /** Keeps only Arabic letters and spaces; drops stray Latin letters, digits and symbols. */
    private fun arabicOnly(raw: String): String =
        raw.filter { isArabic(it) && (it.isLetter() || Character.getType(it) == Character.NON_SPACING_MARK.toInt()) || it == ' ' || it == '\n' }
            .replace("\\s+".toRegex(), " ").trim()

    private fun isReadable(t: String): Boolean {
        val letters = t.count { it.isLetter() }
        return letters >= 5 && t.split(" ").count { w -> w.count { it.isLetter() } >= 2 } >= 1
    }

    private fun handleText(text: String) {
        val words = text.split(" ").filter { it.isNotBlank() }.toSet()
        if (words.isEmpty()) return
        val same = lastWords.intersect(words).size.toFloat() / maxOf(lastWords.size, words.size)
        if (same >= 0.7f) return // same subtitle as before: don't repeat it
        lastWords = words
        runOnUiThread { result.text = text; status.text = "جارٍ النطق" }
        speak(text)
    }

    // ---------- Speech ----------
    private fun speak(text: String) {
        runOnUiThread {
            if (!ttsReady) { status.text = "الصوت العربي غير متاح. ثبّته من إعدادات تحويل النص إلى كلام"; return@runOnUiThread }
            tts.setSpeechRate(voiceSpeed)
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dub-${System.currentTimeMillis()}")
        }
    }

    override fun onInit(code: Int) {
        ttsReady = code == TextToSpeech.SUCCESS &&
            tts.setLanguage(Locale("ar")) >= TextToSpeech.LANG_AVAILABLE
    }

    // ---------- Arabic OCR model ----------
    private fun initArabicOcr() {
        try {
            val dir = File(filesDir, "tessdata").apply { mkdirs() }
            val trained = File(dir, "ara.traineddata")
            val marker = File(dir, "ara.best")
            if (!marker.exists()) {
                // Prefer the more accurate "best" model (downloaded once, then offline).
                try {
                    val tmp = File(dir, "ara.download")
                    URL("https://raw.githubusercontent.com/tesseract-ocr/tessdata_best/main/ara.traineddata")
                        .openStream().use { i -> FileOutputStream(tmp).use { o -> i.copyTo(o) } }
                    if (tmp.length() > 1_000_000) { tmp.copyTo(trained, overwrite = true); marker.createNewFile() }
                    tmp.delete()
                } catch (_: Exception) {}
            }
            if (!trained.exists()) {
                try {
                    assets.open("tessdata/ara.traineddata").use { i ->
                        FileOutputStream(trained).use { o -> i.copyTo(o) }
                    }
                } catch (_: Exception) {}
            }
            if (!trained.exists()) { setStatus("تعذّر تحميل نموذج العربية. تحقق من الإنترنت ثم أعد فتح التطبيق"); return }
            val api = TessBaseAPI()
            if (api.init(filesDir.absolutePath, "ara")) {
                api.pageSegMode = TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK
                ocr = api; setStatus("جاهز. اضغط «ابدأ القراءة»")
            } else api.recycle()
        } catch (e: Exception) { setStatus("خطأ في القراءة العربية: ${e.message}") }
    }

    override fun onDestroy() {
        running.set(false)
        executor.execute { ocr?.recycle() }
        executor.shutdown()
        tts.stop(); tts.shutdown()
        super.onDestroy()
    }
}
