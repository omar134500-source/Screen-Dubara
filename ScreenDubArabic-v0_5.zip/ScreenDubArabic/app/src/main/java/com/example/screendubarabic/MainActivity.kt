package com.example.screendubarabic

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var preview: PreviewView
    private lateinit var guide: View
    private lateinit var status: TextView
    private lateinit var original: TextView
    private lateinit var result: TextView
    private lateinit var startButton: Button
    private lateinit var tts: TextToSpeech
    private lateinit var latinRecognizer: TextRecognizer
    private lateinit var translator: Translator

    private var ttsReady = false
    @Volatile private var translatorReady = false
    private var arabicOcr: TessBaseAPI? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val running = AtomicBoolean(false)
    @Volatile private var bottomPercent = 35
    @Volatile private var voiceSpeed = 1.0f
    private var lastText = ""
    private var lastAnalysis = 0L
    private var cameraStarted = false

    private val permission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) beginReading() else setStatus("لم يتم السماح باستخدام الكاميرا")
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        tts = TextToSpeech(this, this)
        latinRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        translator = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.ARABIC).build()
        )
        setStatus("جارٍ تحميل نموذج الترجمة…")
        translator.downloadModelIfNeeded()
            .addOnSuccessListener { translatorReady = true; setStatus("جاهز. اضغط «ابدأ القراءة»") }
            .addOnFailureListener { setStatus("تعذّر تحميل نموذج الترجمة. تحقق من الإنترنت") }
        executor.execute { initArabicOcr() }
    }

    // ---------- UI (Arabic, right-to-left, one big button) ----------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.parseColor("#111111"))
        }

        preview = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        guide = View(this).apply {
            background = GradientDrawable().apply {
                setStroke(dp(3), Color.parseColor("#FFC107"))
                setColor(Color.parseColor("#22FFC107"))
                cornerRadius = dp(8).toFloat()
            }
        }
        val frame = FrameLayout(this).apply {
            addView(preview, FrameLayout.LayoutParams(-1, -1))
            addView(guide)
        }
        frame.addOnLayoutChangeListener { _, _, t, _, b, _, _, _, _ -> updateGuide(b - t) }
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        original = TextView(this).apply {
            textSize = 14f; setTextColor(Color.parseColor("#AAAAAA")); gravity = Gravity.CENTER
            maxLines = 2; setPadding(dp(12), dp(8), dp(12), 0)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        result = TextView(this).apply {
            text = "ستظهر الترجمة هنا"
            textSize = 24f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE); gravity = Gravity.CENTER
            minLines = 2; maxLines = 4; setPadding(dp(12), dp(4), dp(12), dp(4))
        }
        status = TextView(this).apply {
            textSize = 13f; setTextColor(Color.parseColor("#FFC107")); gravity = Gravity.CENTER
        }
        root.addView(original, LinearLayout.LayoutParams(-1, -2))
        root.addView(result, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))

        // Collapsible settings
        val settings = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            setPadding(dp(16), dp(4), dp(16), dp(4))
        }
        val zoneLabel = label("منطقة الترجمة: أسفل $bottomPercent%")
        val zoneSlider = SeekBar(this).apply {
            max = 60; progress = bottomPercent - 20
            setOnSeekBarChangeListener(simpleSeek { p ->
                bottomPercent = p + 20
                zoneLabel.text = "منطقة الترجمة: أسفل $bottomPercent%"
                updateGuide(preview.height)
            })
        }
        val speedLabel = label("سرعة الصوت: 1.0×")
        val speedSlider = SeekBar(this).apply {
            max = 15; progress = 5
            setOnSeekBarChangeListener(simpleSeek { p ->
                voiceSpeed = 0.5f + p / 10f
                speedLabel.text = "سرعة الصوت: ${"%.1f".format(Locale.US, voiceSpeed)}×"
            })
        }
        listOf(zoneLabel, zoneSlider, speedLabel, speedSlider).forEach { settings.addView(it) }
        root.addView(settings, LinearLayout.LayoutParams(-1, -2))

        val settingsButton = Button(this).apply {
            text = "الإعدادات"; isAllCaps = false
            setOnClickListener {
                settings.visibility = if (settings.visibility == View.GONE) View.VISIBLE else View.GONE
            }
        }
        startButton = Button(this).apply {
            text = "ابدأ القراءة"; textSize = 20f; isAllCaps = false
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2E7D32")); cornerRadius = dp(14).toFloat()
            }
            minHeight = dp(64)
            setOnClickListener { toggle() }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), dp(6), dp(12), dp(12))
            addView(startButton, LinearLayout.LayoutParams(0, -2, 2.2f))
            addView(settingsButton, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        }
        root.addView(row, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun label(t: String) = TextView(this).apply { text = t; setTextColor(Color.WHITE) }

    private fun simpleSeek(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) = onChange(p)
        override fun onStartTrackingTouch(sb: SeekBar?) {}
        override fun onStopTrackingTouch(sb: SeekBar?) {}
    }

    private fun updateGuide(parentHeight: Int) {
        if (parentHeight <= 0) return
        val h = parentHeight * bottomPercent / 100
        guide.layoutParams = FrameLayout.LayoutParams(-1, h, Gravity.BOTTOM).apply {
            setMargins(dp(6), 0, dp(6), dp(6))
        }
    }

    private fun setStatus(t: String) = runOnUiThread { status.text = t }

    // ---------- Start / stop ----------
    private fun toggle() {
        if (running.get()) {
            running.set(false); tts.stop()
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            startButton.text = "ابدأ القراءة"; setStatus("متوقف مؤقتًا")
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) beginReading()
        else permission.launch(Manifest.permission.CAMERA)
    }

    private fun beginReading() {
        running.set(true); lastText = ""
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        startButton.text = "إيقاف"
        setStatus("وجّه الكاميرا إلى الترجمة داخل الإطار الأصفر")
        if (!cameraStarted) startCamera()
    }

    // ---------- Camera + OCR ----------
    private fun startCamera() {
        cameraStarted = true
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(executor) { proxy -> analyze(proxy) }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUseCase, analysis)
            } catch (e: Exception) { setStatus("خطأ في الكاميرا: ${e.message}") }
        }, ContextCompat.getMainExecutor(this))
    }

    /** Runs on the background executor, so heavy OCR never blocks the UI. */
    private fun analyze(proxy: ImageProxy) {
        try {
            val now = System.currentTimeMillis()
            if (!running.get() || now - lastAnalysis < 700) return
            lastAnalysis = now

            val full = proxy.toBitmap()
            val rotated = rotate(full, proxy.imageInfo.rotationDegrees)
            val top = (rotated.height * (100 - bottomPercent) / 100).coerceIn(0, rotated.height - 1)
            val crop = Bitmap.createBitmap(rotated, 0, top, rotated.width, rotated.height - top)

            val latin = try {
                Tasks.await(latinRecognizer.process(InputImage.fromBitmap(crop, 0))).text
            } catch (_: Exception) { "" }
            val arabic = runArabicOcr(crop)
            val text = if (arabic.any { it in '\u0600'..'\u06FF' } && arabic.length >= 3) arabic else latin
            if (text.isNotBlank()) processText(text)
        } catch (e: Exception) {
            setStatus("خطأ: ${e.localizedMessage ?: ""}")
        } finally {
            proxy.close()
        }
    }

    private fun rotate(bmp: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return bmp
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height,
            Matrix().apply { postRotate(degrees.toFloat()) }, true)
    }

    private fun initArabicOcr() {
        try {
            val dir = File(filesDir, "tessdata").apply { mkdirs() }
            val trained = File(dir, "ara.traineddata")
            if (!trained.exists() || trained.length() < 100_000) {
                try {
                    assets.open("tessdata/ara.traineddata").use { i ->
                        FileOutputStream(trained).use { o -> i.copyTo(o) }
                    }
                } catch (_: Exception) {
                    // Not bundled: download the Arabic model once (about 1-2 MB), then it works offline.
                    setStatus("جارٍ تحميل نموذج القراءة العربية…")
                    try {
                        val tmp = File(dir, "ara.download")
                        URL("https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/ara.traineddata")
                            .openStream().use { i -> FileOutputStream(tmp).use { o -> i.copyTo(o) } }
                        if (tmp.length() > 100_000) tmp.renameTo(trained) else tmp.delete()
                    } catch (_: Exception) {}
                }
            }
            if (!trained.exists()) { setStatus("تعذّر تحميل نموذج العربية. تحقق من الإنترنت ثم أعد فتح التطبيق"); return }
            val api = TessBaseAPI()
            if (api.init(filesDir.absolutePath, "ara")) {
                arabicOcr = api; setStatus("القراءة العربية جاهزة")
            } else api.recycle()
        } catch (e: Exception) { setStatus("خطأ في القراءة العربية: ${e.message}") }
    }

    private fun runArabicOcr(bmp: Bitmap): String {
        val api = arabicOcr ?: return ""
        return try { api.setImage(bmp); api.utF8Text?.trim().orEmpty() } catch (_: Exception) { "" }
    }

    // ---------- Text -> speech ----------
    private fun processText(raw: String) {
        val cleaned = raw.replace("\\s+".toRegex(), " ").trim()
        if (cleaned.length < 3 || cleaned == lastText) return
        lastText = cleaned
        val isArabic = cleaned.any { it in '\u0600'..'\u06FF' }
        runOnUiThread { original.text = cleaned }
        if (isArabic) {
            show(cleaned)
        } else if (translatorReady) {
            translator.translate(cleaned)
                .addOnSuccessListener { show(it) }
                .addOnFailureListener { setStatus("فشلت الترجمة") }
        } else setStatus("نموذج الترجمة قيد التحميل، انتظر قليلًا")
    }

    private fun show(arabic: String) {
        runOnUiThread { result.text = arabic; status.text = "جارٍ النطق" }
        speak(arabic)
    }

    private fun speak(text: String) {
        runOnUiThread {
            if (!ttsReady) { status.text = "الصوت العربي غير متاح. ثبّته من إعدادات تحويل النص إلى كلام"; return@runOnUiThread }
            tts.setSpeechRate(voiceSpeed)
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dub-${System.currentTimeMillis()}")
        }
    }

    override fun onInit(code: Int) {
        ttsReady = code == TextToSpeech.SUCCESS &&
            tts.setLanguage(Locale("ar")) >= TextToSpeech.LANG_AVAILABLE
    }

    override fun onDestroy() {
        running.set(false)
        latinRecognizer.close(); translator.close()
        executor.execute { arabicOcr?.recycle() }
        executor.shutdown()
        tts.stop(); tts.shutdown()
        super.onDestroy()
    }
}
