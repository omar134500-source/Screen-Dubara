ضع ملف ara.traineddata في هذا المجلد لتفعيل قراءة النص العربي.
Place ara.traineddata (from the official tessdata repository) in this directory to enable Arabic OCR.
