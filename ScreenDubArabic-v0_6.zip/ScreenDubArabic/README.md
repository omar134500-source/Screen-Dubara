# ScreenDub Arabic — 0.5

يقرأ الترجمة من الشاشة بالكاميرا (إنجليزي أو عربي) ثم يترجمها وينطقها بالعربية.

## تثبيت دائم على الهاتف
1. ارفع محتوى المجلد إلى جذر مستودع GitHub (مع مجلد `.github`).
2. تبويب **Actions** > **Build APK** > انتظر اكتمال البناء.
3. من صفحة التشغيل نزّل **ScreenDubArabic-apk** (ملف zip)، فك الضغط، وثبّت ملف `.apk` على الهاتف (اسمح بالتثبيت من مصدر غير معروف).
التطبيق موقّع بمفتاح ثابت، فالتحديثات المستقبلية تُثبَّت فوق النسخة القديمة دون حذفها.

## Notes
- Arabic OCR model is bundled by the workflow; locally it is downloaded once on first launch.
- Screen stays on while reading. Local build: Android Studio, JDK 17.
- Source only, untested on a device.
